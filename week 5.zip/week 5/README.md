# Advanced Portfolio - Week 5

A modern, responsive portfolio website showcasing advanced CSS techniques including CSS Grid, Flexbox, CSS Variables, animations, and BEM methodology.

## Features

### Advanced CSS Techniques
- **CSS Grid**: Complex layouts with auto-fit and minmax
- **Flexbox**: Responsive navigation and card layouts
- **CSS Variables**: Custom properties for theming
- **Animations**: Smooth transitions and keyframe animations
- **BEM Methodology**: Organized, maintainable CSS

### Multiple Themes
- Light theme (default)
- Dark theme
- Purple theme
- Green theme

### Fully Responsive
- Mobile-first approach
- Breakpoints: 480px, 768px, 1024px
- Responsive navigation with mobile menu
- Flexible grid layouts

### Interactive Features
- Theme switcher with localStorage
- Scroll reveal animations
- Animated skill progress bars
- Smooth scroll navigation
- Active navigation highlighting
- Reading progress bar
- Contact form validation

## Project Structure

week 5/
├── index.html              # Main HTML file
├── css/
│   ├── variables.css       # CSS custom properties
│   ├── base.css           # Reset and base styles
│   ├── layout.css         # Grid and Flexbox layouts
│   ├── components.css     # BEM components
│   ├── animations.css     # Animations and transitions
│   └── themes.css         # Theme variations
├── js/
│   └── theme-switcher.js  # JavaScript functionality
└── images/
    └── (portfolio images)

## Technologies Used

- HTML5 (Semantic markup)
- CSS3 (Grid, Flexbox, Variables, Animations)
- JavaScript (ES6+)
- Font Awesome (Icons)
- Google Fonts (Inter, Poppins)

## CSS Features Demonstrated

### Grid Layouts
- Portfolio grid with `auto-fit` and `minmax()`
- Featured project spanning multiple columns/rows
- Responsive skills grid
- Services grid layout
 
### Flexbox Components
- Navigation bar
- Card layouts
- Footer layout
- Social links

### CSS Variables
- Color schemes
- Spacing system
- Typography scale
- Transition timings
- Shadow system

### Animations
- Fade in/up/down/left/right
- Scale and pulse effects
- Gradient animations
- Scroll reveal
- Skill bar fill animations
- Hover effects

### BEM Methodology
- Block: `.project-card`
- Element: `.project-card__title`
- Modifier: `.project-card--featured`

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Accessibility Features

- Semantic HTML5 elements
- ARIA labels
- Focus visible states
- Reduced motion support
- Keyboard navigation
- Screen reader friendly

## Performance Optimizations

- CSS organized in modular files
- Efficient animations using transform/opacity
- Intersection Observer for scroll animations
- Will-change property for complex animations
- Minimal JavaScript

## How to Use

1. Open `index.html` in a modern browser
2. Try different themes using the theme switcher
3. Scroll to see reveal animations
4. Test responsive design by resizing window
5. Fill out the contact form

## Learning Objectives Covered

CSS Grid for complex layouts
Advanced Flexbox techniques  
CSS Variables for theming
Smooth animations and transitions
BEM methodology
Mobile-first responsive design
Accessibility best practices
Performance optimization

## Future Enhancements

- Add more project examples
- Implement project filtering
- Add testimonials carousel
- Create blog section
- Add more theme options
- Implement dark mode auto-detection