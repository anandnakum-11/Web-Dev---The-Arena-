const themeSwitcher = {
  init() {
    this.buttons = document.querySelectorAll('.theme-switcher__button');
    this.currentTheme = localStorage.getItem('theme') || 'light';

    this.setTheme(this.currentTheme);
    this.attachEventListeners();
  },

  setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
    this.currentTheme = theme;

    this.buttons.forEach(button => {
      if (button.dataset.theme === theme) {
        button.classList.add('theme-switcher__button--active');
      } else {
        button.classList.remove('theme-switcher__button--active');
      }
    });
  },

  attachEventListeners() {
    this.buttons.forEach(button => {
      button.addEventListener('click', () => {
        this.setTheme(button.dataset.theme);
      });
    });
  }
};


const mobileMenu = {
  init() {
    this.toggle = document.getElementById('menu-toggle');
    this.menu = document.getElementById('nav-menu');
    this.links = document.querySelectorAll('.nav__link');

    if (this.toggle && this.menu) {
      this.attachEventListeners();
    }
  },

  toggleMenu() {
    this.menu.classList.toggle('nav__menu--active');
    this.toggle.classList.toggle('menu-toggle--active');
  },

  closeMenu() {
    this.menu.classList.remove('nav__menu--active');
    this.toggle.classList.remove('menu-toggle--active');
  },

  attachEventListeners() {
    this.toggle.addEventListener('click', () => this.toggleMenu());

    this.links.forEach(link => {
      link.addEventListener('click', () => this.closeMenu());
    });
  }
};


const scrollReveal = {
  init() {
    this.elements = document.querySelectorAll('.scroll-reveal');
    this.observer = new IntersectionObserver(
      (entries) => this.handleIntersection(entries),
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    this.elements.forEach(element => this.observer.observe(element));
  },

  handleIntersection(entries) {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('scroll-reveal--visible');
      }
    });
  }
};


const skillBars = {
  init() {
    this.bars = document.querySelectorAll('.skill-bar__fill');
    this.observer = new IntersectionObserver(
      (entries) => this.handleIntersection(entries),
      { threshold: 0.5 }
    );

    this.bars.forEach(bar => this.observer.observe(bar));
  },

  handleIntersection(entries) {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('skill-bar__fill--animated');
      }
    });
  }
};


const header = {
  init() {
    this.element = document.getElementById('header');
    this.attachScrollListener();
  },

  attachScrollListener() {
    let lastScroll = 0;

    window.addEventListener('scroll', () => {
      const currentScroll = window.pageYOffset;

      if (currentScroll > 100) {
        this.element.classList.add('header--scrolled');
      } else {
        this.element.classList.remove('header--scrolled');
      }

      lastScroll = currentScroll;
    });
  }
};


const activeNav = {
  init() {
    this.links = document.querySelectorAll('.nav__link');
    this.sections = document.querySelectorAll('.section, .hero');

    window.addEventListener('scroll', () => this.updateActiveLink());
  },

  updateActiveLink() {
    let current = '';

    this.sections.forEach(section => {
      const sectionTop = section.offsetTop;
      const sectionHeight = section.clientHeight;

      if (window.pageYOffset >= sectionTop - 200) {
        current = section.getAttribute('id');
      }
    });

    this.links.forEach(link => {
      link.classList.remove('nav__link--active');
      if (link.getAttribute('href') === `#${current}`) {
        link.classList.add('nav__link--active');
      }
    });
  }
};


const smoothScroll = {
  init() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', (e) => {
        const href = anchor.getAttribute('href');
        if (href !== '#') {
          e.preventDefault();
          const target = document.querySelector(href);
          if (target) {
            target.scrollIntoView({
              behavior: 'smooth',
              block: 'start'
            });
          }
        }
      });
    });
  }
};


const contactForm = {
  init() {
    this.form = document.getElementById('contact-form');
    if (this.form) {
      this.form.addEventListener('submit', (e) => this.handleSubmit(e));
    }
  },

  handleSubmit(e) {
    e.preventDefault();

    const formData = {
      name: document.getElementById('name').value,
      email: document.getElementById('email').value,
      message: document.getElementById('message').value
    };

    console.log('Form submitted:', formData);

    alert('Thank you for your message! I will get back to you soon.');
    this.form.reset();
  }
};


const progressBar = {
  init() {
    this.bar = document.createElement('div');
    this.bar.className = 'progress-bar';
    document.body.appendChild(this.bar);

    window.addEventListener('scroll', () => this.updateProgress());
  },

  updateProgress() {
    const windowHeight = window.innerHeight;
    const documentHeight = document.documentElement.scrollHeight - windowHeight;
    const scrolled = window.pageYOffset;
    const progress = (scrolled / documentHeight) * 100;

    this.bar.style.transform = `scaleX(${progress / 100})`;
  }
};


document.addEventListener('DOMContentLoaded', () => {
  themeSwitcher.init();
  mobileMenu.init();
  scrollReveal.init();
  skillBars.init();
  header.init();
  activeNav.init();
  smoothScroll.init();
  contactForm.init();
  progressBar.init();
});


window.addEventListener('load', () => {
  document.body.classList.add('loaded');
});
