# TechPulse - Modern Tech News Blog

A fully responsive, feature-rich blog website built with HTML, CSS, and JavaScript. TechPulse is a modern tech news platform showcasing best practices in web development, responsive design, and user experience.

## Features

### Core Functionality
- **5 Fully Responsive Pages**: Homepage, Blog Listing, Single Article, About, and Contact
- **Dark Mode Support**: Toggle between light and dark themes with persistent storage
- **Mobile-First Design**: Optimized for all screen sizes from mobile to desktop
- **Search Functionality**: Quick search overlay for finding articles
- **Interactive Navigation**: Responsive mobile menu with smooth animations

### Homepage
- Hero section with featured article
- Latest articles grid (6 articles)
- Newsletter subscription form
- Category browsing section
- Scroll-to-top button

### Blog Page
- Category filter buttons (All, AI, Web Dev, Mobile, Security)
- Article cards with images and metadata
- Sidebar with popular posts and categories
- Pagination controls
- Newsletter signup widget

### Article Page
- Rich content formatting (headings, lists, blockquotes)
- Author bio section
- Social sharing buttons
- Related articles section
- Table of contents (sidebar)
- Reading time calculator
- Tags and categories

### About Page
- Mission statement
- Company statistics
- Team member profiles
- Core values section
- Call-to-action

### Contact Page
- Validated contact form with real-time error messages
- Contact information cards
- FAQ section
- Map placeholder
- Success message on form submission

## Project Structure

```
week 4/
├── index.html          # Homepage
├── blog.html           # Blog listing page
├── article.html        # Single article template
├── about.html          # About page
├── contact.html        # Contact page
├── css/
│   └── style.css       # Main stylesheet
├── js/
│   └── main.js         # JavaScript functionality
├── images/             # Image assets
│   ├── article-*.jpg   # Article thumbnails
│   ├── author-*.jpg    # Author avatars
│   └── article-hero.jpg # Hero image
└── README.md           # This file
```

## Design Features

### Color Scheme
- **Primary**: Blue (#2563EB)
- **Secondary**: Amber (#F59E0B)
- **Dark Mode**: Sophisticated dark gray palette
- **Typography**: Inter (body), Playfair Display (headings)

### Responsive Breakpoints
- Mobile: < 768px
- Tablet: 768px - 1024px
- Desktop: > 1024px

### Accessibility
- Semantic HTML5 markup
- ARIA labels for interactive elements
- Keyboard navigation support
- High contrast ratios
- Focus indicators

## Technologies Used

- **HTML5**: Semantic markup, meta tags, SEO optimization
- **CSS3**: Flexbox, Grid, CSS Variables, Media Queries, Animations
- **JavaScript**: ES6+, DOM manipulation, Local Storage, Form validation
- **Google Fonts**: Inter, Playfair Display

## JavaScript Features

### Interactive Components
1. **Mobile Menu**: Hamburger menu with smooth toggle animation
2. **Dark Mode**: Theme switcher with localStorage persistence
3. **Search Overlay**: Full-screen search with keyboard shortcuts
4. **Form Validation**: Real-time validation with error messages
5. **Blog Filters**: Category filtering with smooth animations
6. **Newsletter Forms**: Email validation for all newsletter forms
7. **Scroll to Top**: Appears after scrolling 300px
8. **Reading Time**: Automatically calculates article reading time

### Form Validation Rules
- **Name**: Minimum 2 characters, letters only
- **Email**: Valid email format
- **Subject**: Minimum 3 characters
- **Message**: Minimum 10 characters

## Getting Started

### Installation
1. Clone or download this repository
2. No build process required - pure HTML, CSS, and JavaScript
3. Open `index.html` in your browser

### Local Development
Simply open any HTML file in a modern web browser. For best results, use:
- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## 🎯 Key Learning Outcomes

This project demonstrates:
- Semantic HTML5 structure
- Mobile-first responsive design
- CSS Grid and Flexbox layouts
- CSS Variables for theming
- JavaScript DOM manipulation
- Form validation
- Local Storage API
- Event handling
- Accessibility best practices
- SEO optimization

## Pages Overview

### 1. Homepage (index.html)
- Featured article hero section
- Latest articles grid
- Newsletter subscription
- Category cards
- Full navigation and footer

### 2. Blog Listing (blog.html)
- Filterable article list
- Sidebar with popular posts
- Category navigation
- Pagination
- Newsletter widget

### 3. Single Article (article.html)
- Full article content
- Author biography
- Related articles
- Social sharing
- Table of contents
- Comments placeholder

### 4. About (about.html)
- Mission and story
- Team profiles
- Company values
- Statistics
- Call-to-action

### 5. Contact (contact.html)
- Contact form with validation
- Contact information
- FAQ section
- Map placeholder

### Adding Articles
1. Copy an article card from `blog.html`
2. Update the image, title, excerpt, and metadata
3. Link to `article.html` or create a new article page

### Modifying Layout
- Grid layouts use CSS Grid
- Responsive breakpoints in media queries
- Mobile-first approach

## Performance

- Optimized images
- Minimal JavaScript
- CSS animations using GPU acceleration
- No external dependencies (except Google Fonts)
- Fast load times

## Security

- Form validation (client-side)
- XSS prevention through proper HTML escaping
- No sensitive data storage
- HTTPS recommended for production

## Deployment

### GitHub Pages
1. Push code to GitHub repository
2. Go to Settings → Pages
3. Select main branch
4. Your site will be live at `username.github.io/repo-name`

### Netlify
1. Drag and drop the folder to Netlify
2. Or connect your GitHub repository
3. Automatic deployments on push


