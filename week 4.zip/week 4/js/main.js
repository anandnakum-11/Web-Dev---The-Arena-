// TechPulse Blog - Main JavaScript

document.addEventListener('DOMContentLoaded', function () {
    initMobileMenu();
    initDarkMode();
    initSearch();
    initScrollToTop();
    initFormValidation();
    initBlogFilters();
    initNewsletterForms();
    calculateReadingTime();
});

// Mobile Menu
function initMobileMenu() {
    const menuToggle = document.querySelector('.mobile-menu-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (menuToggle && navMenu) {
        menuToggle.addEventListener('click', function () {
            navMenu.classList.toggle('active');

            const spans = this.querySelectorAll('span');
            spans.forEach((span, index) => {
                if (navMenu.classList.contains('active')) {
                    if (index === 0) span.style.transform = 'rotate(45deg) translateY(8px)';
                    if (index === 1) span.style.opacity = '0';
                    if (index === 2) span.style.transform = 'rotate(-45deg) translateY(-8px)';
                } else {
                    span.style.transform = '';
                    span.style.opacity = '';
                }
            });
        });

        const navLinks = navMenu.querySelectorAll('a');
        navLinks.forEach(link => {
            link.addEventListener('click', function () {
                navMenu.classList.remove('active');
                const spans = menuToggle.querySelectorAll('span');
                spans.forEach(span => {
                    span.style.transform = '';
                    span.style.opacity = '';
                });
            });
        });
    }
}

// Dark Mode
function initDarkMode() {
    const darkModeToggle = document.querySelector('.dark-mode-toggle');

    if (darkModeToggle) {
        const savedMode = localStorage.getItem('theme');
        if (savedMode === 'dark') {
            document.body.classList.add('dark-mode');
            darkModeToggle.textContent = '☀️';
        }

        darkModeToggle.addEventListener('click', function () {
            document.body.classList.toggle('dark-mode');
            const isDarkMode = document.body.classList.contains('dark-mode');

            localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
            this.textContent = isDarkMode ? '☀️' : '🌙';
        });
    }
}

// Search Functionality
function initSearch() {
    const searchToggle = document.querySelector('.search-toggle');
    const searchOverlay = document.querySelector('.search-overlay');
    const searchClose = document.querySelector('.search-close');
    const searchInput = document.querySelector('.search-input');

    if (searchToggle && searchOverlay) {
        searchToggle.addEventListener('click', function () {
            searchOverlay.classList.add('active');
            searchInput.focus();
        });

        searchClose.addEventListener('click', function () {
            searchOverlay.classList.remove('active');
        });

        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && searchOverlay.classList.contains('active')) {
                searchOverlay.classList.remove('active');
            }
        });

        searchOverlay.addEventListener('click', function (e) {
            if (e.target === searchOverlay) {
                searchOverlay.classList.remove('active');
            }
        });
    }
}

// Scroll to Top
function initScrollToTop() {
    const scrollButton = document.querySelector('.scroll-to-top');

    if (scrollButton) {
        window.addEventListener('scroll', function () {
            if (window.pageYOffset > 300) {
                scrollButton.classList.add('show');
            } else {
                scrollButton.classList.remove('show');
            }
        });

        scrollButton.addEventListener('click', function () {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
}

// Contact Form Validation
function initFormValidation() {
    const contactForm = document.querySelector('#contact-form');

    if (contactForm) {
        const nameInput = document.querySelector('#name');
        const emailInput = document.querySelector('#email');
        const subjectInput = document.querySelector('#subject');
        const messageInput = document.querySelector('#message');

        nameInput.addEventListener('input', validateName);
        emailInput.addEventListener('input', validateEmail);
        subjectInput.addEventListener('input', validateSubject);
        messageInput.addEventListener('input', validateMessage);

        contactForm.addEventListener('submit', function (e) {
            e.preventDefault();

            const isNameValid = validateName();
            const isEmailValid = validateEmail();
            const isSubjectValid = validateSubject();
            const isMessageValid = validateMessage();

            if (isNameValid && isEmailValid && isSubjectValid && isMessageValid) {
                showSuccessMessage();
                contactForm.reset();
                clearAllErrors();
            }
        });
    }
}

function validateName() {
    const nameInput = document.querySelector('#name');
    const nameError = document.querySelector('#name-error');
    const nameValue = nameInput.value.trim();

    if (nameValue.length < 2) {
        showError(nameInput, nameError, 'Name must be at least 2 characters');
        return false;
    } else if (!/^[a-zA-Z\s]+$/.test(nameValue)) {
        showError(nameInput, nameError, 'Name can only contain letters');
        return false;
    } else {
        clearError(nameInput, nameError);
        return true;
    }
}

function validateEmail() {
    const emailInput = document.querySelector('#email');
    const emailError = document.querySelector('#email-error');
    const emailValue = emailInput.value.trim();
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailPattern.test(emailValue)) {
        showError(emailInput, emailError, 'Please enter a valid email address');
        return false;
    } else {
        clearError(emailInput, emailError);
        return true;
    }
}

function validateSubject() {
    const subjectInput = document.querySelector('#subject');
    const subjectError = document.querySelector('#subject-error');
    const subjectValue = subjectInput.value.trim();

    if (subjectValue.length < 3) {
        showError(subjectInput, subjectError, 'Subject must be at least 3 characters');
        return false;
    } else {
        clearError(subjectInput, subjectError);
        return true;
    }
}

function validateMessage() {
    const messageInput = document.querySelector('#message');
    const messageError = document.querySelector('#message-error');
    const messageValue = messageInput.value.trim();

    if (messageValue.length < 10) {
        showError(messageInput, messageError, 'Message must be at least 10 characters');
        return false;
    } else {
        clearError(messageInput, messageError);
        return true;
    }
}

function showError(input, errorElement, message) {
    input.classList.add('error');
    errorElement.textContent = message;
    errorElement.style.display = 'block';
}

function clearError(input, errorElement) {
    input.classList.remove('error');
    errorElement.textContent = '';
    errorElement.style.display = 'none';
}

function clearAllErrors() {
    const errorElements = document.querySelectorAll('.error-message');
    errorElements.forEach(element => {
        element.style.display = 'none';
        element.textContent = '';
    });

    const inputs = document.querySelectorAll('input, textarea');
    inputs.forEach(input => {
        input.classList.remove('error');
    });
}

function showSuccessMessage() {
    const successMessage = document.querySelector('#contact-success');
    if (successMessage) {
        successMessage.style.display = 'block';

        setTimeout(function () {
            successMessage.style.display = 'none';
        }, 5000);

        // Scroll to success message
        successMessage.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
}

// Blog Filters
function initBlogFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const blogCards = document.querySelectorAll('.blog-card');

    if (filterButtons.length > 0 && blogCards.length > 0) {
        filterButtons.forEach(button => {
            button.addEventListener('click', function () {
                const filter = this.getAttribute('data-category');

                // Update active button
                filterButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');

                // Filter articles
                blogCards.forEach(card => {
                    const category = card.getAttribute('data-category');

                    if (filter === 'all' || category === filter) {
                        card.style.display = 'grid';
                        card.style.animation = 'fadeIn 0.5s ease';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    }
}

// Newsletter Forms
function initNewsletterForms() {
    const newsletterForms = document.querySelectorAll('.newsletter-form, .footer-newsletter-form, .sidebar-newsletter-form');

    newsletterForms.forEach(form => {
        form.addEventListener('submit', function (e) {
            e.preventDefault();

            const emailInput = this.querySelector('input[type="email"]');
            const emailValue = emailInput.value.trim();
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (emailPattern.test(emailValue)) {
                alert('Thank you for subscribing! 🎉');
                emailInput.value = '';
            } else {
                alert('Please enter a valid email address.');
            }
        });
    });
}

// Reading Time Calculator
function calculateReadingTime() {
    const readingTimeElement = document.querySelector('[data-reading-time]');
    const articleBody = document.querySelector('.article-body');

    if (readingTimeElement && articleBody) {
        const text = articleBody.textContent;
        const wordsPerMinute = 200;
        const wordCount = text.trim().split(/\s+/).length;
        const readingTime = Math.ceil(wordCount / wordsPerMinute);

        readingTimeElement.textContent = `${readingTime} min read`;
    }
}

// Fade In Animation

// Add CSS animation
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
`;
document.head.appendChild(style);
