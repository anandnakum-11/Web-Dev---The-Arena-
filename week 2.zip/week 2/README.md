# Week 2: Personal Portfolio Website with CSS Styling

A beautifully styled, responsive personal portfolio website showcasing skills, experience, and contact information with modern CSS design.

## About

This is the personal portfolio of **Anand Nakum**, a passionate web developer and designer. The portfolio demonstrates fundamental web development skills using semantic HTML5 and comprehensive CSS3 styling with responsive design.

## Project Overview

**Week 2 Assignment**: CSS Styling Project  
**Objective**: Add professional CSS styling to the HTML portfolio from Week 1  
**Focus**: CSS selectors, box model, layouts, responsive design, and visual effects

## Features

## Visual Design
 **Modern Color Scheme**: Blue (#4A90E2), Purple (#7B68EE), and Orange (#FF6B6B) gradients
 **Custom Typography**: Google Fonts (Poppins for headings, Open Sans for body)
**Smooth Animations**: Hover effects and transitions throughout
**Professional Layout**: Clean, card-based design with generous whitespace

### CSS Implementation
- **External Stylesheet**: All styles in `style.css`
- **Multiple Selector Types**: Element, ID, and Pseudo-class selectors
- **Box Model**: Proper use of margin, padding, border, and border-radius
- **Flexbox Layout**: Navigation and footer using flexible layouts
- **CSS Grid**: Skills section with responsive grid
- **Responsive Design**: Media queries for tablet (768px) and mobile (480px)

### Interactive Elements
- **Hover Effects**: Navigation links, buttons, sections, and skill cards
- **Focus States**: Form inputs with visual feedback
- **Smooth Scrolling**: Seamless navigation between sections
- **Sticky Header**: Navigation stays visible while scrolling

### Accessibility
- Semantic HTML5 structure
- Proper ARIA labels for screen readers
- Descriptive alt text for images
- Form labels associated with inputs
- Keyboard-friendly navigation

## Sections

### Header
- Gradient background with sticky positioning
- Name and branding with custom typography
- Navigation menu with hover effects:
  - About
  - Skills
  - Contact

### About Me
- Profile image with circular styling and hover animation
- Personal introduction
- Professional background
- Interests and hobbies

### My Skills
- **CSS Grid Layout** with responsive columns
- Skill cards with gradient backgrounds
- Hover animations (lift and scale effects)
- Technical Skills: HTML5, CSS3, JavaScript, Responsive Design
- Soft Skills: Problem Solving, Communication

### Contact
- Styled contact form with focus effects
- Form fields:
  - Name (text input)
  - Email (email input)
  - Message (textarea)
- Gradient submit button with hover effect

### Footer
- Dark background with centered content
- Copyright information
- Social media links with hover effects:
  - [GitHub](https://github.com/)
  - [LinkedIn](https://www.linkedin.com/in/anand-nakum/)
  - Twitter (placeholder)

## Technologies Used

### HTML5
- Semantic markup and structure
- Proper heading hierarchy
- Form validation attributes
- Accessibility features

### CSS3
- **External stylesheet** (`style.css`)
- **Selectors**: Element, ID, Pseudo-class
- **Box Model**: margin, padding, border, border-radius
- **Layout**: Flexbox and CSS Grid
- **Positioning**: Sticky header
- **Typography**: Custom Google Fonts
- **Colors**: Gradients and color schemes
- **Effects**: Transitions, transforms, shadows
- **Responsive**: Media queries for mobile/tablet

## File Structure

week 2/
├── index.html              # Main HTML file with semantic structure
├── style.css               # External CSS stylesheet
├── profile.png             # Profile image
├── README.md               # Project documentation
└── QUALITY_CHECKLIST.md    # Code quality verification

## Getting Started

### Prerequisites
- A modern web browser (Chrome, Firefox, Safari, Edge)
- No additional software required

### Installation

1. Download or clone this repository
2. Ensure all files are in the same directory:
   - `index.html`
   - `style.css`
   - `profile.png`
3. Open `index.html` in your web browser
4. That's it! No build process required.

## CSS Features Demonstrated

### Selectors (3+ Types)
- **Element Selectors**: `body`, `header`, `nav`, `section`, `footer`, etc.
- **ID Selectors**: `#about`, `#skills`, `#contact`
- **Pseudo-class Selectors**: `:hover`, `:focus`, `:active`

### Box Model
- Margin for spacing between elements
- Padding for internal spacing
- Borders with custom colors
- Border-radius for rounded corners

### Layout Systems
- **Flexbox**: Navigation menu and footer links
- **CSS Grid**: Skills section with auto-responsive columns
- **Centering**: Multiple techniques (margin auto, flexbox)

### Responsive Design
- **Tablet (768px)**: Adjusted layouts and font sizes
- **Mobile (480px)**: Single column layouts, compact spacing
- **Mobile-first approach**: Flexible, adaptive design

### Visual Effects
- Gradient backgrounds
- Box shadows for depth
- Smooth transitions (0.3s ease)
- Transform effects (translateY, scale, rotate)
- Hover animations on all interactive elements

## Browser Compatibility

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Code Quality

### Improvements from Week 1
- **Consistent indentation** (4 spaces throughout)
- **HTML comments** for section clarity
- **Proper formatting** (no multi-line attributes)
- **Clean CSS organization** with clear comments
- **Best practices** followed throughout

### Standards Compliance
- W3C HTML5 valid
- Modern CSS3 standards
- WCAG accessibility guidelines
- Industry-standard formatting

## Learning Outcomes

This project demonstrates understanding of:
- CSS selectors and specificity
- Box model (margin, padding, border)
- Flexbox and CSS Grid layouts
- Responsive design with media queries
- CSS positioning (sticky)
- Typography and custom fonts
- Color theory and gradients
- Transitions and animations
- Hover effects and interactivity
- Code organization and best practices

## Author

**Anand Nakum**  
Web Developer & Designer
