# Personal Portfolio Website
A clean and beginner-friendly personal portfolio website showcasing my skills, projects, and contact information.

## About

This is the personal portfolio of Anand Nakum, a passionate web developer and designer. The portfolio demonstrates fundamental web development skills using semantic HTML5.

## Features

- Responsive Design: Built with semantic HTML5 structure
- Internal Navigation: Smooth navigation between sections using anchor links
- About Section: Personal introduction with profile information
- Skills Section: Comprehensive list of technical and soft skills
- Contact Form: Functional contact form for visitor inquiries
- Social Links: Direct links to GitHub and LinkedIn profiles
- Accessibility: Proper ARIA labels and semantic HTML tags

## Sections

### Header
- Name and branding
- Navigation menu with links to:
  - About
  - Skills
  - Contact

### About Me
- Personal introduction
- Professional background
- Interests and hobbies

### My Skills
- Technical Skills: HTML5, CSS3, JavaScript, Responsive Design
- Soft Skills: Problem Solving, Communication

### Contact
- Contact form with fields for:
  - Name
  - Email
  - Message
- Submit button

### Footer
- Copyright information
- Social media links:
  - [GitHub](https://github.com/)
  - [LinkedIn](https://www.linkedin.com/in/anand-nakum/)
  - Twitter (placeholder)

## Getting Started

### Prerequisites
- A modern web browser (Chrome, Firefox, Safari, Edge)

### Installation

1. Clone or download this repository
2. Open `index.html` in your web browser
3. That's it! No build process required.

## Navigation

The portfolio uses internal anchor links for smooth navigation:
- Clicking navigation items scrolls to the corresponding section
- Each section has a unique `id` attribute (`#about`, `#skills`, `#contact`)

## Technologies Used

- HTML5: Semantic markup and structure
- Accessibility: ARIA labels for better screen reader support
