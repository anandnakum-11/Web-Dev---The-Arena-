# Week 3: Interactive Portfolio Website with JavaScript

A fully interactive personal portfolio website with advanced JavaScript features including form validation, dark/light mode toggle, dynamic filtering, and smooth animations.

## About

This is the personal portfolio of **Anand Nakum**, a passionate web developer and designer. The portfolio demonstrates comprehensive web development skills using semantic HTML5, modern CSS3, and interactive JavaScript functionality.

## Project Overview

**Week 3 Assignment**: JavaScript Interactive Features  
**Objective**: Add JavaScript functionality to enhance user experience  
**Focus**: Form validation, DOM manipulation, event handling, and interactive features

## Features

### JavaScript Interactive Features
**Form Validation** - Real-time validation with error messages  
**Dark/Light Mode Toggle** - Theme switcher with localStorage persistence  
**Skills Filter** - Dynamic filtering by category (All, Technical, Soft Skills)  
**Scroll-to-Top Button** - Floating button with smooth scroll  
**Typing Animation** - Animated header text with rotating phrases

### Visual Design
- **Modern Color Scheme**: Blue (#4A90E2), Purple (#7B68EE), and Orange (#FF6B6B) gradients
- **Dark Mode Support**: Complete dark theme with smooth transitions
- **Custom Typography**: Google Fonts (Poppins for headings, Open Sans for body)
- **Smooth Animations**: Hover effects, transitions, and dynamic animations
- **Professional Layout**: Clean, card-based design with generous whitespace

### CSS Implementation
- **External Stylesheet**: All styles in `style.css`
- **CSS Variables**: For dark mode theme switching
- **Multiple Selector Types**: Element, ID, Class, and Pseudo-class selectors
- **Box Model**: Proper use of margin, padding, border, and border-radius
- **Flexbox Layout**: Navigation and footer using flexible layouts
- **CSS Grid**: Skills section with responsive grid
- **Responsive Design**: Media queries for tablet (768px) and mobile (480px)

### Interactive Elements
- **Form Validation**: Real-time error messages and success feedback
- **Dark Mode Toggle**: Persistent theme preference
- **Skills Filter**: Category-based filtering with animations
- **Scroll Button**: Auto-show/hide based on scroll position
- **Typing Effect**: Continuous typewriter animation
- **Hover Effects**: Navigation links, buttons, sections, and skill cards
- **Focus States**: Form inputs with visual feedback

## Sections

### Header
- Gradient background with sticky positioning
- Name and branding with custom typography
- **Typing Animation**: Rotating phrases (Web Developer, Designer, Problem Solver, Creative Thinker)
- **Dark Mode Toggle**: Moon/Sun icon button
- Navigation menu with hover effects:
  - About
  - Skills
  - Contact

### About Me
- Profile image with circular styling and hover animation
- Personal introduction
- Professional background
- Interests and hobbies

### My Skills
- **CSS Grid Layout** with responsive columns
- **Filter Buttons**: All Skills, Technical, Soft Skills
- Skill cards with gradient backgrounds
- Hover animations (lift and scale effects)
- **Technical Skills**: HTML5, CSS3, JavaScript, Responsive Design
- **Soft Skills**: Problem Solving, Communication

### Contact
- **Form Validation** with real-time error messages
- **Success Message**: Confirmation on valid submission
- Form fields:
  - Name (minimum 2 characters, letters only)
  - Email (valid email format required)
  - Message (minimum 10 characters)
- Gradient submit button with hover effect

### Footer
- Dark background with centered content
- Copyright information
- Social media links with hover effects:
  - [GitHub](https://github.com/)
  - [LinkedIn](https://www.linkedin.com/in/anand-nakum/)
  - Twitter (placeholder)

## Technologies Used

### HTML5
- Semantic markup and structure
- Proper heading hierarchy
- Form validation attributes
- Data attributes for filtering
- Accessibility features

### CSS3
- **External stylesheet** (`style.css`)
- **CSS Variables** for dark mode
- **Selectors**: Element, ID, Class, Pseudo-class
- **Box Model**: margin, padding, border, border-radius
- **Layout**: Flexbox and CSS Grid
- **Positioning**: Sticky header, fixed scroll button
- **Typography**: Custom Google Fonts
- **Colors**: Gradients and dynamic color schemes
- **Effects**: Transitions, transforms, shadows, animations
- **Responsive**: Media queries for mobile/tablet

### JavaScript (ES6)
- **External script** (`script.js`)
- **DOM Manipulation**: querySelector, querySelectorAll
- **Event Listeners**: submit, input, click, scroll, DOMContentLoaded
- **Form Validation**: Regex patterns, real-time validation
- **localStorage API**: Theme persistence
- **Animations**: Typewriter effect with recursive functions
- **Conditional Logic**: if/else, ternary operators
- **Array Methods**: forEach, iteration
- **Browser APIs**: scrollTo, setTimeout, pageYOffset

## File Structure

```
week 3/
├── index.html              # Main HTML file with semantic structure
├── style.css               # External CSS stylesheet with dark mode
├── script.js               # JavaScript file with all interactive features
├── profile.png             # Profile image
└── README.md               # Project documentation
```

## Getting Started

### Prerequisites
- A modern web browser (Chrome, Firefox, Safari, Edge)
- No additional software required

### Installation

1. Download or clone this repository
2. Ensure all files are in the same directory:
   - `index.html`
   - `style.css`
   - `script.js`
   - `profile.png`
3. Open `index.html` in your web browser
4. That's it! No build process required.

## JavaScript Features Demonstrated

### 1. Form Validation
- **Name Validation**: Minimum 2 characters, letters only
- **Email Validation**: Proper email format using regex
- **Message Validation**: Minimum 10 characters
- **Real-time Feedback**: Error messages on input
- **Success Message**: Confirmation on valid submission
- **Form Reset**: Clears form after successful submission

### 2. Dark/Light Mode Toggle
- **Toggle Button**: Moon/Sun icon in header
- **CSS Variables**: Dynamic theme switching
- **localStorage**: Saves user preference
- **Smooth Transitions**: 0.3s color transitions
- **Persistent**: Remembers choice on page reload

### 3. Skills Filter
- **Filter Buttons**: All, Technical, Soft Skills
- **Dynamic Filtering**: Show/hide based on category
- **Data Attributes**: `data-category` for categorization
- **Fade Animations**: Smooth appearance effects
- **Active State**: Highlights selected filter

### 4. Scroll-to-Top Button
- **Auto Show/Hide**: Appears after 300px scroll
- **Smooth Scroll**: Animated scroll to top
- **Fixed Position**: Bottom-right corner
- **Fade Effect**: Opacity transitions

### 5. Typing Animation
- **Typewriter Effect**: Character-by-character typing
- **Multiple Phrases**: 4 rotating messages
- **Continuous Loop**: Never-ending animation
- **Variable Speed**: Different typing/deleting speeds
- **Blinking Cursor**: CSS animation

## DOM Manipulation Techniques

### Element Selection
- `querySelector()` - Single element selection
- `querySelectorAll()` - Multiple elements selection

### Content Manipulation
- `textContent` - Update text content
- `value` - Get/set input values

### Style Manipulation
- `style.display` - Show/hide elements
- `classList.add()` - Add CSS classes
- `classList.remove()` - Remove CSS classes
- `classList.toggle()` - Toggle CSS classes

### Attribute Manipulation
- `getAttribute()` - Read data attributes
- `setAttribute()` - Set attributes

## Event Listeners

- **Form Events**: `submit`, `input`
- **Click Events**: Button clicks, filter buttons
- **Scroll Events**: `window.scroll` for scroll button
- **Page Load**: `DOMContentLoaded` for initialization

## Browser Compatibility

Chrome (latest)  
Firefox (latest)  
Safari (latest)  
Edge (latest)  
Mobile browsers (iOS Safari, Chrome Mobile)

## Code Quality

### JavaScript Best Practices
- **Clean Code**: Simplified comments, clear function names
- **Modular Functions**: Reusable, single-purpose functions
- **Consistent Naming**: camelCase for variables and functions
- **Error Handling**: Validation and edge case handling
- **Code Organization**: Logical sections with clear structure

### Standards Compliance
- W3C HTML5 valid
- Modern CSS3 standards
- ES6 JavaScript features
- WCAG accessibility guidelines
- Industry-standard formatting

## Learning Outcomes

This project demonstrates understanding of:
- JavaScript fundamentals (variables, functions, conditionals)
- DOM manipulation and selection
- Event handling and listeners
- Form validation with regex patterns
- localStorage API for data persistence
- CSS class manipulation
- Animations and transitions
- Responsive design with media queries
- Code organization and best practices
- Debugging and testing

## Author

**Anand Nakum**  
Web Developer & Designer
