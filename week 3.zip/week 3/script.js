// Wait for DOM to fully load
document.addEventListener('DOMContentLoaded', function () {
    initFormValidation();
    initDarkModeToggle();
    initSkillsFilter();
    initScrollToTop();
    initTypingAnimation();
});

// ============================================
// FORM VALIDATION
// ============================================

function initFormValidation() {
    const form = document.querySelector('#contact form');
    const nameInput = document.querySelector('#name');
    const emailInput = document.querySelector('#email');
    const messageInput = document.querySelector('#message');

    // Real-time validation
    nameInput.addEventListener('input', validateName);
    emailInput.addEventListener('input', validateEmail);
    messageInput.addEventListener('input', validateMessage);

    // Form submission
    form.addEventListener('submit', function (event) {
        event.preventDefault();

        const isNameValid = validateName();
        const isEmailValid = validateEmail();
        const isMessageValid = validateMessage();

        if (isNameValid && isEmailValid && isMessageValid) {
            showSuccessMessage();
            form.reset();
            clearAllErrors();
        }
    });
}

function validateName() {
    const nameInput = document.querySelector('#name');
    const nameValue = nameInput.value.trim();
    const nameError = document.querySelector('#name-error');

    if (nameValue.length < 2) {
        showError(nameInput, nameError, 'Name must be at least 2 characters long');
        return false;
    } else if (!/^[a-zA-Z\s]+$/.test(nameValue)) {
        showError(nameInput, nameError, 'Name can only contain letters');
        return false;
    } else {
        clearError(nameInput, nameError);
        return true;
    }
}

function validateEmail() {
    const emailInput = document.querySelector('#email');
    const emailValue = emailInput.value.trim();
    const emailError = document.querySelector('#email-error');
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailPattern.test(emailValue)) {
        showError(emailInput, emailError, 'Please enter a valid email address');
        return false;
    } else {
        clearError(emailInput, emailError);
        return true;
    }
}

function validateMessage() {
    const messageInput = document.querySelector('#message');
    const messageValue = messageInput.value.trim();
    const messageError = document.querySelector('#message-error');

    if (messageValue.length < 10) {
        showError(messageInput, messageError, 'Message must be at least 10 characters long');
        return false;
    } else {
        clearError(messageInput, messageError);
        return true;
    }
}

function showError(input, errorElement, message) {
    input.classList.add('error');
    errorElement.textContent = message;
    errorElement.style.display = 'block';
}

function clearError(input, errorElement) {
    input.classList.remove('error');
    errorElement.textContent = '';
    errorElement.style.display = 'none';
}

function clearAllErrors() {
    const errorElements = document.querySelectorAll('.error-message');
    errorElements.forEach(function (element) {
        element.style.display = 'none';
        element.textContent = '';
    });

    const inputs = document.querySelectorAll('input, textarea');
    inputs.forEach(function (input) {
        input.classList.remove('error');
    });
}

function showSuccessMessage() {
    const successMessage = document.querySelector('#success-message');
    successMessage.style.display = 'block';

    setTimeout(function () {
        successMessage.style.display = 'none';
    }, 5000);
}

// ============================================
// DARK MODE TOGGLE
// ============================================

function initDarkModeToggle() {
    const toggleButton = document.querySelector('#dark-mode-toggle');

    // Load saved preference
    const savedMode = localStorage.getItem('theme');
    if (savedMode === 'dark') {
        document.body.classList.add('dark-mode');
        updateToggleIcon(true);
    }

    // Toggle on click
    toggleButton.addEventListener('click', function () {
        document.body.classList.toggle('dark-mode');
        const isDarkMode = document.body.classList.contains('dark-mode');

        localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
        updateToggleIcon(isDarkMode);
    });
}

function updateToggleIcon(isDarkMode) {
    const toggleButton = document.querySelector('#dark-mode-toggle');
    toggleButton.textContent = isDarkMode ? '☀️' : '🌙';
}

// ============================================
// SKILLS FILTER
// ============================================

function initSkillsFilter() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const skillItems = document.querySelectorAll('#skills li');

    filterButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            const filter = this.getAttribute('data-filter');

            // Update active button
            filterButtons.forEach(function (btn) {
                btn.classList.remove('active');
            });
            this.classList.add('active');

            // Filter skills
            skillItems.forEach(function (skill) {
                const category = skill.getAttribute('data-category');

                if (filter === 'all' || category === filter) {
                    skill.style.display = 'block';
                    skill.classList.add('fade-in');
                } else {
                    skill.style.display = 'none';
                    skill.classList.remove('fade-in');
                }
            });
        });
    });
}

// ============================================
// SCROLL TO TOP BUTTON
// ============================================

function initScrollToTop() {
    const scrollButton = document.querySelector('#scroll-to-top');

    // Show/hide based on scroll position
    window.addEventListener('scroll', function () {
        if (window.pageYOffset > 300) {
            scrollButton.classList.add('show');
        } else {
            scrollButton.classList.remove('show');
        }
    });

    // Scroll to top on click
    scrollButton.addEventListener('click', function () {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
}

// ============================================
// TYPING ANIMATION
// ============================================

function initTypingAnimation() {
    const typingElement = document.querySelector('#typing-text');
    const phrases = [
        'Web Developer',
        'Designer',
        'Problem Solver',
        'Creative Thinker'
    ];

    let phraseIndex = 0;
    let charIndex = 0;
    let isDeleting = false;

    function type() {
        const currentPhrase = phrases[phraseIndex];

        if (isDeleting) {
            typingElement.textContent = currentPhrase.substring(0, charIndex - 1);
            charIndex--;
        } else {
            typingElement.textContent = currentPhrase.substring(0, charIndex + 1);
            charIndex++;
        }

        let typeSpeed = isDeleting ? 50 : 100;

        if (!isDeleting && charIndex === currentPhrase.length) {
            typeSpeed = 2000;
            isDeleting = true;
        } else if (isDeleting && charIndex === 0) {
            isDeleting = false;
            phraseIndex = (phraseIndex + 1) % phrases.length;
            typeSpeed = 500;
        }

        setTimeout(type, typeSpeed);
    }

    type();
}
